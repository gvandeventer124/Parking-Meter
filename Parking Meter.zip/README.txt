Graham Van Deventer - 001404877
Jack Snopek - 001408851
Nickolas Morrison - 001426613

On Pay By Cash Screen
q = insert nickel
w = insert dime
e = insert quarter
r = insert loonie
t = insert toonie
y = insert $5
u = insert $10
i = inset $20

On Pay by Card Screen
space = swipe card

On main menu screen
space = Insert Ticket