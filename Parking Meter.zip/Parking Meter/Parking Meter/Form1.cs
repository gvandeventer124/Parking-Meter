﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parking_Meter
{
    public partial class Form1 : Form
    {
        string datetime = DateTime.Now.ToString();
        int hour = DateTime.Now.Hour % 12;
        double min = DateTime.Now.Minute % 60;
        double cost = 0;
        Boolean cash = false;
        double cashpaid = 0;
        Boolean card = false;
        double price = 0;
        int delay = 0;
        string returntime = "";//
        string payment = "";//
        string owed = "";//
        string paid = "";//
        string change = "";
        string phonenumber = "";
        string temperature = "";//
        int weathersector = 0;//
        Boolean am = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            timer1.Start();
            phonenumcheck.Start();
            hr.Text = hour.ToString();
            if(hour == 12)
            {
                hr.Text = ("12");
            }
            if (min < 10)
            {
                Minute.Text = ("0" + min.ToString());
            }
            else
            {
                Minute.Text = min.ToString();
            }
            hr1t.Text = ((hour + 1)%12).ToString() + (":00");
            hr2t.Text = ((hour + 2)%12).ToString() + (":00");
            hr3t.Text = ((hour + 3)%12).ToString() + (":00");
            hr4t.Text = ((hour + 4)%12).ToString() + (":00");
            if(hour == 8)
            {
                hr4t.Text = ("12:00");
            }
            if (hour == 9)
            {
                hr3t.Text = ("12:00");
            }
            if (hour == 10)
            {
                hr2t.Text = ("12:00");
            }
            if (hour == 11)
            {
                hr1t.Text = ("12:00");
            }
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            cashpaid = 0;
            Loop.Stop();
            timer2.Stop();
            delay = 0;
            panel1.Visible = false;
            panel2.Visible = true;
            label22.Text = "Deposited: $0.00";
            cashpaid = 0;
            timeindicator.Location = new Point((Convert.ToInt32(min/ 60 * 172)+2), timeindicator.Location.Y);
            weathersector = 0;
            label45.Text = DateTime.Now.AddHours(weathersector).ToString("tt");

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            datetime = DateTime.Now.ToString();
            Time.Text = datetime;
            Time2.Text = datetime;
            Time3.Text = datetime;
            label19.Text = datetime;
            label25.Text = datetime;
            label40.Text = datetime;
            label31.Text = datetime;
            label18.Text = datetime;
            label14.Text = datetime;
            label28.Text = datetime;
        }

        private void label10_Click(object sender, EventArgs e)
        {
            hour = hour + 1;
            hr.Text = hour.ToString();
            weathersector = weathersector + 1;
            label45.Text = DateTime.Now.AddHours(weathersector).ToString("tt");

            cost = cost + 100;
            TotalCost.Text = ("Total: $" + (cost / 100).ToString("N2"));
            int newpos = timeindicator.Location.X + 172;
            timeindicator.Location = new Point (newpos, timeindicator.Location.Y);
            if(cost > 300)
            {
                addhr.Visible = false;
            }
            if(cost == 400)
            {
                add15min.Visible = false;
            }
            drophr.Visible = true;
            drop15min.Visible = true;
        }

        private void label11_Click(object sender, EventArgs e)
        {
            hour = hour - 1;
            hour = (hour % 12);
            weathersector = weathersector - 1;
            label45.Text = DateTime.Now.AddHours(weathersector).ToString("tt");

            if (hour == 0)
            {
                hour = 12;
            }
            hr.Text = hour.ToString();
            cost = cost - 100;
            TotalCost.Text = ("Total: $" + (cost / 100).ToString("N2"));
            int newpos = timeindicator.Location.X - 172;
            timeindicator.Location = new Point(newpos, timeindicator.Location.Y);
            if (cost < 100)
            {
                drophr.Visible = false;
            }
            if (cost == 0)
            {
                drop15min.Visible = false;
            }
            addhr.Visible = true;
            add15min.Visible = true;
        }

        private void label12_Click(object sender, EventArgs e)
        {
            min = min + 15;
            if (min >= 60)
            {
                hour = hour + 1;
                weathersector = weathersector + 1;
                label45.Text = DateTime.Now.AddHours(weathersector).ToString("tt");
                hr.Text = hour.ToString();
            }
            min = min % 60;
            if (min < 10)
            {
                Minute.Text = ("0" + min.ToString());
            }
            else
            {
                Minute.Text = min.ToString();
            }
            cost = cost + 25;
            TotalCost.Text = ("Total: $" + (cost / 100).ToString("N2"));
            int newpos = timeindicator.Location.X + 172/4;
            timeindicator.Location = new Point(newpos, timeindicator.Location.Y);
            if (cost > 300)
            {
                addhr.Visible = false;
            }
            if (cost == 400)
            {
                add15min.Visible = false;
            }
            drop15min.Visible = true;
            if (cost >= 100)
            {
                drophr.Visible = true;
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
            min = min - 15;
            if(min <= 0)
            {
                hour = hour - 1;
                weathersector = weathersector - 1;
                label45.Text = DateTime.Now.AddHours(weathersector).ToString("tt");
                hr.Text = hour.ToString();
                min = 60 + min;
            }
            if (min < 10)
            {
                Minute.Text = ("0" + min.ToString());
            }
            else
            {
                Minute.Text = min.ToString();
            }
            cost = cost - 25;
            TotalCost.Text = ("Total: $" + (cost / 100).ToString("N2"));
            int newpos = timeindicator.Location.X - 172/4;
            timeindicator.Location = new Point(newpos, timeindicator.Location.Y);
            if (cost < 100)
            {
                drophr.Visible = false;
            }
            if (cost == 0)
            {
                drop15min.Visible = false;
            }
            add15min.Visible = true;
            addhr.Visible = true;
        }

        private void label15_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            resetPanel2();
            panel2.Visible = false;
        }
        private void resetPanel2()
        {
            drop15min.Visible = false;
            drophr.Visible = false;
            cost = 0;
            TotalCost.Text = ("Total: $0.00");
            hour = DateTime.Now.Hour % 12;
            min = DateTime.Now.Minute % 60;
            hr.Text = hour.ToString();
            if (min < 10)
            {
                Minute.Text = "0" + min.ToString();
            }
            else Minute.Text = min.ToString();
        }

        private void label14_Click(object sender, EventArgs e)
        {
            returntime = hour.ToString() + ":" + min.ToString("00");
            owed = (cost / 100).ToString();
            if(weathersector == 0 || weathersector == 2 || weathersector == 4)
            {
                temperature = "5 C";
            }
            else if (weathersector == 1)
            {
                temperature = "4 C";
            }
            else
            {
                temperature = "6 C";
            }
            panel7.Visible = true;
            price = cost;
            owed = (price / 100).ToString("N2");
            label13.Text = ("Total: $" + (cost/100).ToString("N2"));
            resetPanel2();
            label21.Text = ("Total: $" + (price / 100).ToString("N2"));
            panel2.Visible = false;
        }

        private void label16_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            timeindicator.Location = new Point((Convert.ToInt32(min / 60 * 172) + 2), timeindicator.Location.Y);
            cashdone.Visible = false;
            panel1.Visible = true;
        }

        private void label10_Click_1(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = true;
            cashdone.Visible = false;
            cash = true;
            payment = "Cash";
        }

        private void label18_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            panel3.Visible = true;
            cash = false;
            cashdone.Visible = false;
            cashpaid = 0;
            label22.Text = "Deposited: $0.00";
        }

        private void cash_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cash)
            {
                if (e.KeyChar == 'q')
                {
                    cashpaid = cashpaid + 5;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 'w')
                {
                    cashpaid = cashpaid + 10;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 'e')
                {
                    cashpaid = cashpaid + 25;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 'r')
                {
                    cashpaid = cashpaid + 100;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 't')
                {
                    cashpaid = cashpaid + 200;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 'y')
                {
                    cashpaid = cashpaid + 500;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 'u')
                {
                    cashpaid = cashpaid + 1000;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if (e.KeyChar == 'i')
                {
                    cashpaid = cashpaid + 2000;
                    label22.Text = ("Deposited: $" + (cashpaid / 100).ToString("N2"));
                }
                if(cashpaid >= price)
                {
                    cashdone.Visible = true;
                }
            }
            if (card)
            {
                if (e.KeyChar == ' ' && panel5.Visible)
                {
                    panel5.Visible = false;
                    panel8.Visible = true;
                    card = false;
                    Loop.Start();
                }

            }
            else
            {
                if (e.KeyChar == ' ')
                {
                    if (panel1.Visible == true)
                    {
                        panel1.Visible = false;
                        panel9.Visible = true;
                        timer2.Start();
                    }
                }
            }
        }

        private void label11_Click_1(object sender, EventArgs e)
        {
            label27.Text = ("Total: $" + (price / 100).ToString("N2"));
            payment = "Card";
            panel3.Visible = false;
            panel5.Visible = true;
            card = true;
        }

        private void label12_Click_1(object sender, EventArgs e)
        {
            payment = "Account";
            timer3.Start();
            change = "0.00";
            panel3.Visible = false;
            panel6.Visible = true;
            label11.Text = "Total: $" + (price/100).ToString("N2");
        }

        private void label28_Click(object sender, EventArgs e)
        {
            timer3.Stop();
                panel6.Visible = false;
                panel8.Visible = true;
                Loop.Start();
        }

        private void phonenumcheck_Tick(object sender, EventArgs e)
        {
            string phone = textBox4.Text;
            Boolean wrong = false;
            if (phone.Length != 10)
            {
                wrong = true;
            }
            foreach (char c in phone)
            {
                if (c < '0' || c > '9')
                {
                    wrong = true;
                }
            }
            if (wrong != true)
            {
                label35.Visible = true;
            }
            else
            {
                label35.Visible = false;
            }
        }

        private void accback_Click(object sender, EventArgs e)
        {
            timer3.Stop();
            panel6.Visible = false;
            panel3.Visible = true;
        }

        private void cardback_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
            card = false;
            panel3.Visible = true;
        }

        private void cashdone_Click(object sender, EventArgs e)
        {
            change = ((cashpaid - price)/100).ToString();
            paid = (cashpaid/100).ToString();
            panel8.Visible = true;
            panel4.Visible = false;
            Loop.Start();
        }

        private void label35_Click(object sender, EventArgs e)
        {
            label39.Text = temperature;
            phonenumber = textBox4.Text;
            label42.Image = imageList1.Images[weathersector];
            label36.Text = (returntime + DateTime.Now.AddHours(weathersector).ToString("tt") + "\n\n" + phonenumber + "\n\n$" + owed);
            panel10.Visible = true;
            panel7.Visible = false;
        }

        private void Loop_Tick(object sender, EventArgs e)
        {
            delay = delay + 1;
            if (delay >= 75)
            {
                panel8.Visible = false;
                panel1.Visible = true;
                delay = 0;
                Loop.Stop();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            delay = delay + 1;
            if (delay >= 100)
            {
                panel9.Visible = false;
                panel1.Visible = true;
                delay = 0;
                timer2.Stop();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label37_Click(object sender, EventArgs e)
        {
            label39.Text = temperature;
            label42.Image = imageList1.Images[weathersector];
            phonenumber = "None Given";
            panel10.Visible = true;
            panel7.Visible = false;

            label36.Text = (returntime + DateTime.Now.AddHours(weathersector).ToString("tt") + "\n\n" + phonenumber + "\n\n$" + owed);
        }

        private void label44_Click(object sender, EventArgs e)
        {
            panel10.Visible = false;
            panel3.Visible = true;
        }

        private void label43_Click(object sender, EventArgs e)
        {
            panel10.Visible = false;
            panel1.Visible = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label47_Click(object sender, EventArgs e)
        {

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            string accnum = textBox1.Text;
            string pin = textBox2.Text;
            foreach (char c in accnum)
            {
                if (c < '0' || c > '9')
                {
                    textBox1.Text = String.Empty;
                    textBox2.Text = String.Empty;
                }
            }
            foreach (char c in pin)
            {
                if (c < '0' || c > '9')
                {
                    textBox1.Text = String.Empty;
                    textBox2.Text = String.Empty;
                }
            }
            accnum = textBox1.Text;
            pin = textBox2.Text;
            if (accnum.Length == 6 && pin.Length == 4)
            { 
                accdone.Visible = true;
            }
            
        }

        private void label48_Click(object sender, EventArgs e)
        {
            MessageBox.Show("For Help Please Call 555-555-5555");
        }
    }
}
