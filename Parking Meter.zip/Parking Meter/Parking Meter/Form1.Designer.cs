﻿namespace Parking_Meter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Time = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.timeindicator = new System.Windows.Forms.Label();
            this.backtomain = new System.Windows.Forms.Label();
            this.timedone = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TotalCost = new System.Windows.Forms.Label();
            this.hr4t = new System.Windows.Forms.Label();
            this.hr3t = new System.Windows.Forms.Label();
            this.hr2t = new System.Windows.Forms.Label();
            this.Time2 = new System.Windows.Forms.Label();
            this.hr1t = new System.Windows.Forms.Label();
            this.hr5 = new System.Windows.Forms.Label();
            this.hr4 = new System.Windows.Forms.Label();
            this.hr3 = new System.Windows.Forms.Label();
            this.hr2 = new System.Windows.Forms.Label();
            this.hr1 = new System.Windows.Forms.Label();
            this.Minute = new System.Windows.Forms.Label();
            this.hr = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.addhr = new System.Windows.Forms.Label();
            this.drophr = new System.Windows.Forms.Label();
            this.add15min = new System.Windows.Forms.Label();
            this.drop15min = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.paymentback = new System.Windows.Forms.Label();
            this.Time3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.accstart = new System.Windows.Forms.Label();
            this.cardstart = new System.Windows.Forms.Label();
            this.cashstart = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label54 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.cashdone = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.cashback = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label52 = new System.Windows.Forms.Label();
            this.Swipe = new System.Windows.Forms.Label();
            this.cardback = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label27 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.accdone = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.accback = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label48 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.phonenumcheck = new System.Windows.Forms.Timer(this.components);
            this.panel8 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Loop = new System.Windows.Forms.Timer(this.components);
            this.panel9 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel10 = new System.Windows.Forms.Panel();
            this.label55 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.ConfirmationInfo = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(297, 118);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(299, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.panel1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(230, 237);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(407, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tap Anywhere To Continue";
            this.label2.Click += new System.EventHandler(this.panel1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(260, 402);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(344, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Insert Ticket Below For Refund";
            this.label3.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label53);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Time);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(855, 485);
            this.panel1.TabIndex = 3;
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(721, 44);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(67, 25);
            this.label53.TabIndex = 39;
            this.label53.Text = "HELP";
            this.label53.Click += new System.EventHandler(this.label48_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(109, 44);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(33, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "5 C";
            this.label5.Click += new System.EventHandler(this.panel1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.panel1_Click);
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(728, 3);
            this.Time.Name = "Time";
            this.Time.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Time.Size = new System.Drawing.Size(34, 13);
            this.Time.TabIndex = 3;
            this.Time.Text = " TIme";
            this.Time.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Time.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label51);
            this.panel2.Controls.Add(this.label45);
            this.panel2.Controls.Add(this.timeindicator);
            this.panel2.Controls.Add(this.backtomain);
            this.panel2.Controls.Add(this.timedone);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.TotalCost);
            this.panel2.Controls.Add(this.hr4t);
            this.panel2.Controls.Add(this.hr3t);
            this.panel2.Controls.Add(this.hr2t);
            this.panel2.Controls.Add(this.Time2);
            this.panel2.Controls.Add(this.hr1t);
            this.panel2.Controls.Add(this.hr5);
            this.panel2.Controls.Add(this.hr4);
            this.panel2.Controls.Add(this.hr3);
            this.panel2.Controls.Add(this.hr2);
            this.panel2.Controls.Add(this.hr1);
            this.panel2.Controls.Add(this.Minute);
            this.panel2.Controls.Add(this.hr);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.addhr);
            this.panel2.Controls.Add(this.drophr);
            this.panel2.Controls.Add(this.add15min);
            this.panel2.Controls.Add(this.drop15min);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(855, 485);
            this.panel2.TabIndex = 4;
            this.panel2.Visible = false;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(735, 44);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(67, 25);
            this.label51.TabIndex = 39;
            this.label51.Text = "HELP";
            this.label51.Click += new System.EventHandler(this.label48_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(544, 200);
            this.label45.Name = "label45";
            this.label45.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label45.Size = new System.Drawing.Size(51, 55);
            this.label45.TabIndex = 31;
            this.label45.Text = "0";
            // 
            // timeindicator
            // 
            this.timeindicator.AutoSize = true;
            this.timeindicator.ForeColor = System.Drawing.Color.Red;
            this.timeindicator.Location = new System.Drawing.Point(166, 394);
            this.timeindicator.Name = "timeindicator";
            this.timeindicator.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.timeindicator.Size = new System.Drawing.Size(13, 13);
            this.timeindicator.TabIndex = 30;
            this.timeindicator.Text = "v";
            // 
            // backtomain
            // 
            this.backtomain.BackColor = System.Drawing.Color.DarkTurquoise;
            this.backtomain.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backtomain.Location = new System.Drawing.Point(31, 334);
            this.backtomain.Name = "backtomain";
            this.backtomain.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.backtomain.Size = new System.Drawing.Size(142, 48);
            this.backtomain.TabIndex = 29;
            this.backtomain.Text = "< BACK";
            this.backtomain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.backtomain.Click += new System.EventHandler(this.label15_Click);
            // 
            // timedone
            // 
            this.timedone.BackColor = System.Drawing.Color.DarkTurquoise;
            this.timedone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timedone.Location = new System.Drawing.Point(682, 334);
            this.timedone.Name = "timedone";
            this.timedone.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.timedone.Size = new System.Drawing.Size(142, 48);
            this.timedone.TabIndex = 28;
            this.timedone.Text = "DONE >";
            this.timedone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.timedone.Click += new System.EventHandler(this.label14_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(48, 205);
            this.label9.Name = "label9";
            this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label9.Size = new System.Drawing.Size(162, 25);
            this.label9.TabIndex = 27;
            this.label9.Text = "Max Stay: 4 hrs";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(48, 176);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 26;
            this.label4.Text = "$1 / Hour";
            // 
            // TotalCost
            // 
            this.TotalCost.AutoSize = true;
            this.TotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCost.Location = new System.Drawing.Point(320, 330);
            this.TotalCost.Name = "TotalCost";
            this.TotalCost.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TotalCost.Size = new System.Drawing.Size(227, 42);
            this.TotalCost.TabIndex = 25;
            this.TotalCost.Text = "Total: $0.00";
            // 
            // hr4t
            // 
            this.hr4t.AutoSize = true;
            this.hr4t.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr4t.Location = new System.Drawing.Point(663, 394);
            this.hr4t.Name = "hr4t";
            this.hr4t.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr4t.Size = new System.Drawing.Size(35, 13);
            this.hr4t.TabIndex = 24;
            this.hr4t.Text = "label9";
            this.hr4t.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hr3t
            // 
            this.hr3t.AutoSize = true;
            this.hr3t.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr3t.Location = new System.Drawing.Point(497, 394);
            this.hr3t.Name = "hr3t";
            this.hr3t.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr3t.Size = new System.Drawing.Size(35, 13);
            this.hr3t.TabIndex = 23;
            this.hr3t.Text = "label9";
            this.hr3t.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hr2t
            // 
            this.hr2t.AutoSize = true;
            this.hr2t.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr2t.Location = new System.Drawing.Point(324, 394);
            this.hr2t.Name = "hr2t";
            this.hr2t.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr2t.Size = new System.Drawing.Size(35, 13);
            this.hr2t.TabIndex = 22;
            this.hr2t.Text = "label9";
            this.hr2t.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Time2
            // 
            this.Time2.AutoSize = true;
            this.Time2.Location = new System.Drawing.Point(728, 3);
            this.Time2.Name = "Time2";
            this.Time2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Time2.Size = new System.Drawing.Size(34, 13);
            this.Time2.TabIndex = 21;
            this.Time2.Text = " TIme";
            this.Time2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // hr1t
            // 
            this.hr1t.AutoSize = true;
            this.hr1t.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr1t.Location = new System.Drawing.Point(155, 394);
            this.hr1t.Name = "hr1t";
            this.hr1t.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr1t.Size = new System.Drawing.Size(35, 13);
            this.hr1t.TabIndex = 20;
            this.hr1t.Text = "label9";
            this.hr1t.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hr5
            // 
            this.hr5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hr5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr5.Image = ((System.Drawing.Image)(resources.GetObject("hr5.Image")));
            this.hr5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hr5.Location = new System.Drawing.Point(689, 402);
            this.hr5.Name = "hr5";
            this.hr5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr5.Size = new System.Drawing.Size(171, 81);
            this.hr5.TabIndex = 19;
            this.hr5.Text = "5 C";
            this.hr5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // hr4
            // 
            this.hr4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hr4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr4.Image = ((System.Drawing.Image)(resources.GetObject("hr4.Image")));
            this.hr4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hr4.Location = new System.Drawing.Point(518, 402);
            this.hr4.Name = "hr4";
            this.hr4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr4.Size = new System.Drawing.Size(172, 81);
            this.hr4.TabIndex = 18;
            this.hr4.Text = "6 C";
            this.hr4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // hr3
            // 
            this.hr3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hr3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr3.Image = ((System.Drawing.Image)(resources.GetObject("hr3.Image")));
            this.hr3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hr3.Location = new System.Drawing.Point(346, 402);
            this.hr3.Name = "hr3";
            this.hr3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr3.Size = new System.Drawing.Size(172, 81);
            this.hr3.TabIndex = 17;
            this.hr3.Text = "5 C";
            this.hr3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // hr2
            // 
            this.hr2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hr2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr2.Image = ((System.Drawing.Image)(resources.GetObject("hr2.Image")));
            this.hr2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hr2.Location = new System.Drawing.Point(174, 402);
            this.hr2.Name = "hr2";
            this.hr2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr2.Size = new System.Drawing.Size(172, 81);
            this.hr2.TabIndex = 16;
            this.hr2.Text = "4 C";
            this.hr2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // hr1
            // 
            this.hr1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr1.Image = ((System.Drawing.Image)(resources.GetObject("hr1.Image")));
            this.hr1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hr1.Location = new System.Drawing.Point(2, 406);
            this.hr1.Name = "hr1";
            this.hr1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr1.Size = new System.Drawing.Size(172, 77);
            this.hr1.TabIndex = 15;
            this.hr1.Text = "5 C";
            this.hr1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Minute
            // 
            this.Minute.AutoSize = true;
            this.Minute.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Minute.Location = new System.Drawing.Point(452, 200);
            this.Minute.Name = "Minute";
            this.Minute.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Minute.Size = new System.Drawing.Size(51, 55);
            this.Minute.TabIndex = 9;
            this.Minute.Text = "0";
            // 
            // hr
            // 
            this.hr.AutoSize = true;
            this.hr.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hr.Location = new System.Drawing.Point(345, 200);
            this.hr.Name = "hr";
            this.hr.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.hr.Size = new System.Drawing.Size(51, 55);
            this.hr.TabIndex = 8;
            this.hr.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(109, 44);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(33, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "5 C";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(87, 93);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(708, 42);
            this.label6.TabIndex = 0;
            this.label6.Text = "Please Enter the Time You Will Return By";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // addhr
            // 
            this.addhr.AutoSize = true;
            this.addhr.BackColor = System.Drawing.SystemColors.MenuText;
            this.addhr.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addhr.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addhr.Location = new System.Drawing.Point(348, 163);
            this.addhr.Name = "addhr";
            this.addhr.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.addhr.Size = new System.Drawing.Size(47, 55);
            this.addhr.TabIndex = 10;
            this.addhr.Text = "^";
            this.addhr.Click += new System.EventHandler(this.label10_Click);
            // 
            // drophr
            // 
            this.drophr.AutoSize = true;
            this.drophr.BackColor = System.Drawing.SystemColors.MenuText;
            this.drophr.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drophr.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.drophr.Location = new System.Drawing.Point(348, 240);
            this.drophr.Name = "drophr";
            this.drophr.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.drophr.Size = new System.Drawing.Size(48, 55);
            this.drophr.TabIndex = 11;
            this.drophr.Text = "v";
            this.drophr.Visible = false;
            this.drophr.Click += new System.EventHandler(this.label11_Click);
            // 
            // add15min
            // 
            this.add15min.AutoSize = true;
            this.add15min.BackColor = System.Drawing.SystemColors.MenuText;
            this.add15min.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add15min.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.add15min.Location = new System.Drawing.Point(452, 163);
            this.add15min.Name = "add15min";
            this.add15min.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.add15min.Size = new System.Drawing.Size(47, 55);
            this.add15min.TabIndex = 12;
            this.add15min.Text = "^";
            this.add15min.Click += new System.EventHandler(this.label12_Click);
            // 
            // drop15min
            // 
            this.drop15min.AutoSize = true;
            this.drop15min.BackColor = System.Drawing.SystemColors.MenuText;
            this.drop15min.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drop15min.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.drop15min.Location = new System.Drawing.Point(452, 240);
            this.drop15min.Name = "drop15min";
            this.drop15min.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.drop15min.Size = new System.Drawing.Size(48, 55);
            this.drop15min.TabIndex = 13;
            this.drop15min.Text = "v";
            this.drop15min.Visible = false;
            this.drop15min.Click += new System.EventHandler(this.label13_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(409, 196);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(37, 55);
            this.label8.TabIndex = 14;
            this.label8.Text = ":";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label50);
            this.panel3.Controls.Add(this.paymentback);
            this.panel3.Controls.Add(this.Time3);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.accstart);
            this.panel3.Controls.Add(this.cardstart);
            this.panel3.Controls.Add(this.cashstart);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(855, 485);
            this.panel3.TabIndex = 28;
            this.panel3.Visible = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(732, 44);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(67, 25);
            this.label50.TabIndex = 39;
            this.label50.Text = "HELP";
            this.label50.Click += new System.EventHandler(this.label48_Click);
            // 
            // paymentback
            // 
            this.paymentback.BackColor = System.Drawing.Color.DarkTurquoise;
            this.paymentback.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentback.Location = new System.Drawing.Point(7, 428);
            this.paymentback.Name = "paymentback";
            this.paymentback.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.paymentback.Size = new System.Drawing.Size(142, 48);
            this.paymentback.TabIndex = 31;
            this.paymentback.Text = "CANCEL";
            this.paymentback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.paymentback.Click += new System.EventHandler(this.label16_Click);
            // 
            // Time3
            // 
            this.Time3.AutoSize = true;
            this.Time3.Location = new System.Drawing.Point(732, 3);
            this.Time3.Name = "Time3";
            this.Time3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Time3.Size = new System.Drawing.Size(34, 13);
            this.Time3.TabIndex = 30;
            this.Time3.Text = " TIme";
            this.Time3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(113, 44);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label17.Size = new System.Drawing.Size(33, 20);
            this.label17.TabIndex = 29;
            this.label17.Text = "5 C";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(7, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 28;
            this.pictureBox3.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(320, 25);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(215, 42);
            this.label13.TabIndex = 26;
            this.label13.Text = "Total: $0.00";
            // 
            // accstart
            // 
            this.accstart.BackColor = System.Drawing.Color.DarkTurquoise;
            this.accstart.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accstart.Image = ((System.Drawing.Image)(resources.GetObject("accstart.Image")));
            this.accstart.Location = new System.Drawing.Point(574, 102);
            this.accstart.Name = "accstart";
            this.accstart.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.accstart.Size = new System.Drawing.Size(200, 300);
            this.accstart.TabIndex = 2;
            this.accstart.Text = "Account Number";
            this.accstart.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.accstart.Click += new System.EventHandler(this.label12_Click_1);
            // 
            // cardstart
            // 
            this.cardstart.BackColor = System.Drawing.Color.DarkTurquoise;
            this.cardstart.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardstart.Image = ((System.Drawing.Image)(resources.GetObject("cardstart.Image")));
            this.cardstart.Location = new System.Drawing.Point(332, 102);
            this.cardstart.Name = "cardstart";
            this.cardstart.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cardstart.Size = new System.Drawing.Size(200, 300);
            this.cardstart.TabIndex = 1;
            this.cardstart.Text = "Card\r\n";
            this.cardstart.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.cardstart.Click += new System.EventHandler(this.label11_Click_1);
            // 
            // cashstart
            // 
            this.cashstart.BackColor = System.Drawing.Color.DarkTurquoise;
            this.cashstart.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashstart.Image = ((System.Drawing.Image)(resources.GetObject("cashstart.Image")));
            this.cashstart.Location = new System.Drawing.Point(91, 102);
            this.cashstart.Name = "cashstart";
            this.cashstart.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cashstart.Size = new System.Drawing.Size(200, 300);
            this.cashstart.TabIndex = 0;
            this.cashstart.Text = "Cash\r\n";
            this.cashstart.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.cashstart.Click += new System.EventHandler(this.label10_Click_1);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label54);
            this.panel4.Controls.Add(this.label46);
            this.panel4.Controls.Add(this.cashdone);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.cashback);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Location = new System.Drawing.Point(12, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(855, 485);
            this.panel4.TabIndex = 32;
            this.panel4.Visible = false;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(735, 44);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(67, 25);
            this.label54.TabIndex = 39;
            this.label54.Text = "HELP";
            this.label54.Click += new System.EventHandler(this.label48_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(242, 351);
            this.label46.Name = "label46";
            this.label46.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label46.Size = new System.Drawing.Size(375, 24);
            this.label46.TabIndex = 34;
            this.label46.Text = "Please Insert Coins or Bills into the Terminal";
            // 
            // cashdone
            // 
            this.cashdone.BackColor = System.Drawing.Color.DarkTurquoise;
            this.cashdone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashdone.Location = new System.Drawing.Point(703, 428);
            this.cashdone.Name = "cashdone";
            this.cashdone.Size = new System.Drawing.Size(142, 48);
            this.cashdone.TabIndex = 33;
            this.cashdone.Text = "DONE";
            this.cashdone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cashdone.Click += new System.EventHandler(this.cashdone_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(282, 258);
            this.label22.Name = "label22";
            this.label22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label22.Size = new System.Drawing.Size(301, 42);
            this.label22.TabIndex = 32;
            this.label22.Text = "Deposited: $0.00";
            // 
            // cashback
            // 
            this.cashback.BackColor = System.Drawing.Color.DarkTurquoise;
            this.cashback.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashback.Location = new System.Drawing.Point(7, 428);
            this.cashback.Name = "cashback";
            this.cashback.Size = new System.Drawing.Size(142, 48);
            this.cashback.TabIndex = 31;
            this.cashback.Text = "BACK >";
            this.cashback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cashback.Click += new System.EventHandler(this.label18_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(732, 3);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label19.Size = new System.Drawing.Size(34, 13);
            this.label19.TabIndex = 30;
            this.label19.Text = " TIme";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(113, 44);
            this.label20.Name = "label20";
            this.label20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label20.Size = new System.Drawing.Size(33, 20);
            this.label20.TabIndex = 29;
            this.label20.Text = "5 C";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(7, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 100);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 28;
            this.pictureBox4.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(320, 141);
            this.label21.Name = "label21";
            this.label21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label21.Size = new System.Drawing.Size(215, 42);
            this.label21.TabIndex = 26;
            this.label21.Text = "Total: $0.00";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label52);
            this.panel5.Controls.Add(this.Swipe);
            this.panel5.Controls.Add(this.cardback);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Location = new System.Drawing.Point(12, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(855, 485);
            this.panel5.TabIndex = 32;
            this.panel5.Visible = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(735, 42);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(67, 25);
            this.label52.TabIndex = 41;
            this.label52.Text = "HELP";
            this.label52.Click += new System.EventHandler(this.label48_Click);
            // 
            // Swipe
            // 
            this.Swipe.AutoSize = true;
            this.Swipe.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Swipe.Location = new System.Drawing.Point(63, 221);
            this.Swipe.Name = "Swipe";
            this.Swipe.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Swipe.Size = new System.Drawing.Size(733, 84);
            this.Swipe.TabIndex = 32;
            this.Swipe.Text = "Please Swipe Or Insert Your Card Now\r\nAnd Follow the Instructions on the Terminal" +
    "\r\n";
            this.Swipe.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cardback
            // 
            this.cardback.BackColor = System.Drawing.Color.DarkTurquoise;
            this.cardback.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardback.Location = new System.Drawing.Point(7, 428);
            this.cardback.Name = "cardback";
            this.cardback.Size = new System.Drawing.Size(142, 48);
            this.cardback.TabIndex = 31;
            this.cardback.Text = "BACK >";
            this.cardback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cardback.Click += new System.EventHandler(this.cardback_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(732, 3);
            this.label25.Name = "label25";
            this.label25.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label25.Size = new System.Drawing.Size(34, 13);
            this.label25.TabIndex = 30;
            this.label25.Text = " TIme";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(113, 44);
            this.label26.Name = "label26";
            this.label26.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label26.Size = new System.Drawing.Size(33, 20);
            this.label26.TabIndex = 29;
            this.label26.Text = "5 C";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(7, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 100);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 28;
            this.pictureBox5.TabStop = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(320, 25);
            this.label27.Name = "label27";
            this.label27.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label27.Size = new System.Drawing.Size(215, 42);
            this.label27.TabIndex = 26;
            this.label27.Text = "Total: $0.00";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label49);
            this.panel6.Controls.Add(this.label47);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label34);
            this.panel6.Controls.Add(this.textBox2);
            this.panel6.Controls.Add(this.textBox1);
            this.panel6.Controls.Add(this.label33);
            this.panel6.Controls.Add(this.accdone);
            this.panel6.Controls.Add(this.label29);
            this.panel6.Controls.Add(this.accback);
            this.panel6.Controls.Add(this.label31);
            this.panel6.Controls.Add(this.label32);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Location = new System.Drawing.Point(12, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(855, 485);
            this.panel6.TabIndex = 33;
            this.panel6.Visible = false;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(731, 59);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(67, 25);
            this.label49.TabIndex = 40;
            this.label49.Text = "HELP";
            this.label49.Click += new System.EventHandler(this.label48_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(329, 394);
            this.label47.Name = "label47";
            this.label47.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label47.Size = new System.Drawing.Size(200, 24);
            this.label47.TabIndex = 39;
            this.label47.Text = "Use the Keypad Below";
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(326, 44);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(215, 42);
            this.label11.TabIndex = 38;
            this.label11.Text = "Total: $0.00";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(154, 118);
            this.label34.Name = "label34";
            this.label34.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label34.Size = new System.Drawing.Size(571, 24);
            this.label34.TabIndex = 37;
            this.label34.Text = "It seems there was an error with your information. Please Try Again.";
            this.label34.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(333, 313);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox2.Size = new System.Drawing.Size(293, 20);
            this.textBox2.TabIndex = 36;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(333, 205);
            this.textBox1.Name = "textBox1";
            this.textBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox1.Size = new System.Drawing.Size(293, 20);
            this.textBox1.TabIndex = 35;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(230, 286);
            this.label33.Name = "label33";
            this.label33.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label33.Size = new System.Drawing.Size(253, 24);
            this.label33.TabIndex = 34;
            this.label33.Text = "Please Enter Your 4 Digit PIN";
            // 
            // accdone
            // 
            this.accdone.BackColor = System.Drawing.Color.DarkTurquoise;
            this.accdone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accdone.Location = new System.Drawing.Point(703, 428);
            this.accdone.Name = "accdone";
            this.accdone.Size = new System.Drawing.Size(142, 48);
            this.accdone.TabIndex = 33;
            this.accdone.Text = "DONE";
            this.accdone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.accdone.Visible = false;
            this.accdone.Click += new System.EventHandler(this.label28_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(230, 178);
            this.label29.Name = "label29";
            this.label29.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label29.Size = new System.Drawing.Size(367, 24);
            this.label29.TabIndex = 32;
            this.label29.Text = "Please Enter Your 6 Digit Account Number";
            // 
            // accback
            // 
            this.accback.BackColor = System.Drawing.Color.DarkTurquoise;
            this.accback.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accback.Location = new System.Drawing.Point(7, 428);
            this.accback.Name = "accback";
            this.accback.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.accback.Size = new System.Drawing.Size(142, 48);
            this.accback.TabIndex = 31;
            this.accback.Text = "< BACK";
            this.accback.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.accback.Click += new System.EventHandler(this.accback_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(732, 3);
            this.label31.Name = "label31";
            this.label31.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label31.Size = new System.Drawing.Size(34, 13);
            this.label31.TabIndex = 30;
            this.label31.Text = " TIme";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(113, 44);
            this.label32.Name = "label32";
            this.label32.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label32.Size = new System.Drawing.Size(33, 20);
            this.label32.TabIndex = 29;
            this.label32.Text = "5 C";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(7, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(100, 100);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 28;
            this.pictureBox6.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label48);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Controls.Add(this.label35);
            this.panel7.Controls.Add(this.textBox4);
            this.panel7.Controls.Add(this.label37);
            this.panel7.Controls.Add(this.label38);
            this.panel7.Controls.Add(this.label40);
            this.panel7.Controls.Add(this.label41);
            this.panel7.Controls.Add(this.pictureBox7);
            this.panel7.Location = new System.Drawing.Point(12, 12);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(855, 485);
            this.panel7.TabIndex = 38;
            this.panel7.Visible = false;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(731, 59);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(67, 25);
            this.label48.TabIndex = 39;
            this.label48.Text = "HELP";
            this.label48.Click += new System.EventHandler(this.label48_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(304, 253);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(296, 72);
            this.label10.TabIndex = 37;
            this.label10.Text = "Phone Numbers are 10 digits long\r\nNo non-numerical characters\r\n(Use the Keypad Be" +
    "low)";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(703, 373);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label35.Size = new System.Drawing.Size(142, 48);
            this.label35.TabIndex = 36;
            this.label35.Text = "DONE";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.Visible = false;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(306, 220);
            this.textBox4.Name = "textBox4";
            this.textBox4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.textBox4.Size = new System.Drawing.Size(293, 20);
            this.textBox4.TabIndex = 35;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(703, 428);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label37.Size = new System.Drawing.Size(142, 48);
            this.label37.TabIndex = 33;
            this.label37.Text = "SKIP";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(257, 135);
            this.label38.Name = "label38";
            this.label38.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label38.Size = new System.Drawing.Size(390, 72);
            this.label38.TabIndex = 32;
            this.label38.Text = "If you would like a text message reminding \r\nyou when your parking time is about " +
    "to expire\r\nplease enter your phone number below";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(732, 3);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label40.Size = new System.Drawing.Size(34, 13);
            this.label40.TabIndex = 30;
            this.label40.Text = " TIme";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(113, 44);
            this.label41.Name = "label41";
            this.label41.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label41.Size = new System.Drawing.Size(33, 20);
            this.label41.TabIndex = 29;
            this.label41.Text = "5 C";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(7, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(100, 100);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 28;
            this.pictureBox7.TabStop = false;
            // 
            // phonenumcheck
            // 
            this.phonenumcheck.Tick += new System.EventHandler(this.phonenumcheck_Tick);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.label23);
            this.panel8.Controls.Add(this.pictureBox8);
            this.panel8.Controls.Add(this.label16);
            this.panel8.Location = new System.Drawing.Point(12, 12);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(855, 485);
            this.panel8.TabIndex = 39;
            this.panel8.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(732, 3);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(34, 13);
            this.label18.TabIndex = 30;
            this.label18.Text = " TIme";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(113, 44);
            this.label23.Name = "label23";
            this.label23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label23.Size = new System.Drawing.Size(33, 20);
            this.label23.TabIndex = 29;
            this.label23.Text = "5 C";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(7, 3);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(100, 100);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 28;
            this.pictureBox8.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(65, 154);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label16.Size = new System.Drawing.Size(730, 219);
            this.label16.TabIndex = 32;
            this.label16.Text = "Thank you very much!\r\nPlease Take Your Ticket\r\nHave a Nice Day!";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Loop
            // 
            this.Loop.Interval = 25;
            this.Loop.Tick += new System.EventHandler(this.Loop_Tick);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label14);
            this.panel9.Controls.Add(this.label15);
            this.panel9.Controls.Add(this.pictureBox9);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Location = new System.Drawing.Point(12, 12);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(855, 485);
            this.panel9.TabIndex = 40;
            this.panel9.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(732, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = " TIme";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(113, 44);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(33, 20);
            this.label15.TabIndex = 29;
            this.label15.Text = "5 C";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(7, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(100, 100);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 28;
            this.pictureBox9.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(151, 156);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(588, 195);
            this.label12.TabIndex = 32;
            this.label12.Text = "Thank You For Returning Your Ticket\r\nYour Refund Is Being Processed\r\nPlease Take " +
    "Your Refund From the\r\nChange Slot\r\n!Have a Nice Day";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer2
            // 
            this.timer2.Interval = 25;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label55);
            this.panel10.Controls.Add(this.label44);
            this.panel10.Controls.Add(this.label43);
            this.panel10.Controls.Add(this.label39);
            this.panel10.Controls.Add(this.label36);
            this.panel10.Controls.Add(this.ConfirmationInfo);
            this.panel10.Controls.Add(this.label28);
            this.panel10.Controls.Add(this.label30);
            this.panel10.Controls.Add(this.pictureBox10);
            this.panel10.Controls.Add(this.label24);
            this.panel10.Controls.Add(this.label42);
            this.panel10.Location = new System.Drawing.Point(12, 12);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(855, 485);
            this.panel10.TabIndex = 40;
            this.panel10.Visible = false;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(735, 44);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(67, 25);
            this.label55.TabIndex = 41;
            this.label55.Text = "HELP";
            this.label55.Click += new System.EventHandler(this.label48_Click);
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(705, 428);
            this.label44.Name = "label44";
            this.label44.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label44.Size = new System.Drawing.Size(142, 48);
            this.label44.TabIndex = 39;
            this.label44.Text = "CONFIRM";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(7, 428);
            this.label43.Name = "label43";
            this.label43.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label43.Size = new System.Drawing.Size(142, 48);
            this.label43.TabIndex = 38;
            this.label43.Text = "CANCEL";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(606, 290);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label39.Size = new System.Drawing.Size(56, 31);
            this.label39.TabIndex = 36;
            this.label39.Text = "5 C";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(477, 139);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(170, 140);
            this.label36.TabIndex = 35;
            this.label36.Text = "Time of Return:\r\nTotal Cost: $\r\nAmount Paid: $\r\nChange Owed: $\r\nPayment Method: \r" +
    "\nPhone Number:\r\nWeather Upon Return:\r\n";
            // 
            // ConfirmationInfo
            // 
            this.ConfirmationInfo.AutoSize = true;
            this.ConfirmationInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmationInfo.Location = new System.Drawing.Point(276, 139);
            this.ConfirmationInfo.Name = "ConfirmationInfo";
            this.ConfirmationInfo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ConfirmationInfo.Size = new System.Drawing.Size(170, 140);
            this.ConfirmationInfo.TabIndex = 34;
            this.ConfirmationInfo.Text = "Time of Return:\r\n\r\nPhone Number:\r\n\r\nAmount Owed:\r\n\r\nWeather Upon Return:\r\n";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(732, 3);
            this.label28.Name = "label28";
            this.label28.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label28.Size = new System.Drawing.Size(34, 13);
            this.label28.TabIndex = 30;
            this.label28.Text = " TIme";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(113, 44);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label30.Size = new System.Drawing.Size(33, 20);
            this.label30.TabIndex = 29;
            this.label30.Text = "5 C";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(7, 3);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(100, 100);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox10.TabIndex = 28;
            this.pictureBox10.TabStop = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(197, 6);
            this.label24.Name = "label24";
            this.label24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label24.Size = new System.Drawing.Size(493, 126);
            this.label24.TabIndex = 32;
            this.label24.Text = "Please Confirm \r\nThe Following Information \r\nBefore Your Ticket Is Printed";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.ImageList = this.imageList1;
            this.label42.Location = new System.Drawing.Point(436, 284);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(200, 200);
            this.label42.TabIndex = 37;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "cloud.png");
            this.imageList1.Images.SetKeyName(1, "rain.png");
            this.imageList1.Images.SetKeyName(2, "suncloud.png");
            this.imageList1.Images.SetKeyName(3, "sun.png");
            this.imageList1.Images.SetKeyName(4, "suncloud.png");
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(879, 509);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cash_KeyPress);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label hr;
        private System.Windows.Forms.Label Minute;
        private System.Windows.Forms.Label addhr;
        private System.Windows.Forms.Label drophr;
        private System.Windows.Forms.Label add15min;
        private System.Windows.Forms.Label drop15min;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label hr1t;
        private System.Windows.Forms.Label hr5;
        private System.Windows.Forms.Label hr4;
        private System.Windows.Forms.Label hr3;
        private System.Windows.Forms.Label hr2;
        private System.Windows.Forms.Label hr1;
        private System.Windows.Forms.Label Time2;
        private System.Windows.Forms.Label hr4t;
        private System.Windows.Forms.Label hr3t;
        private System.Windows.Forms.Label hr2t;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label TotalCost;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label accstart;
        private System.Windows.Forms.Label cardstart;
        private System.Windows.Forms.Label cashstart;
        private System.Windows.Forms.Label backtomain;
        private System.Windows.Forms.Label timedone;
        private System.Windows.Forms.Label Time3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label paymentback;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label cashback;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label cashdone;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label Swipe;
        private System.Windows.Forms.Label cardback;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label accdone;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label accback;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Timer phonenumcheck;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Timer Loop;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label timeindicator;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label ConfirmationInfo;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label55;
    }
}

